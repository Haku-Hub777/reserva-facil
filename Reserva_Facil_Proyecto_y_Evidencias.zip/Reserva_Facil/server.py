"""Run Reserva Fácil with Python 3.10 or newer."""

import argparse
import json
import re
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from reservas import InvalidReservation, NotFound, Reservations, RoomUnavailable


WEB = Path(__file__).resolve().with_name("web")
STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        url = urlsplit(self.path)
        if url.path in STATIC:
            filename, content_type = STATIC[url.path]
            self.send_content(HTTPStatus.OK, (WEB / filename).read_bytes(), content_type)
            return
        if url.path == "/api/availability":
            query = parse_qs(url.query)
            self.respond(lambda: {
                "rooms": self.server.reservations.available(
                    query.get("start", [None])[0], query.get("end", [None])[0]
                )
            })
            return
        if url.path == "/api/reservations":
            self.respond(lambda: {"reservations": self.server.reservations.list_all()})
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "Recurso no encontrado."})

    def do_POST(self):
        if urlsplit(self.path).path == "/api/reservations":
            self.respond(lambda: self.server.reservations.create(self.read_json()), HTTPStatus.CREATED)
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "Recurso no encontrado."})

    def do_PATCH(self):
        route = re.fullmatch(r"/api/reservations/([1-9][0-9]{0,17})/cancel", urlsplit(self.path).path)
        if route is None:
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "Recurso no encontrado."})
            return
        self.respond(lambda: self.server.reservations.cancel(int(route.group(1))))

    def read_json(self):
        if self.headers.get_content_type() != "application/json":
            raise InvalidReservation("Envía los datos de la reserva en formato JSON.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 4096:
                raise ValueError
            data = json.loads(self.rfile.read(length))
        except (ValueError, UnicodeError):
            raise InvalidReservation("Los datos de la reserva no tienen un formato válido.") from None
        if not isinstance(data, dict):
            raise InvalidReservation("Los datos de la reserva no tienen un formato válido.")
        return data

    def respond(self, operation, status=HTTPStatus.OK):
        try:
            self.send_json(status, operation())
        except InvalidReservation as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
        except RoomUnavailable as error:
            self.send_json(HTTPStatus.CONFLICT, {"error": str(error)})
        except NotFound as error:
            self.send_json(HTTPStatus.NOT_FOUND, {"error": str(error)})

    def send_json(self, status, data):
        self.send_content(status, json.dumps(data, ensure_ascii=False).encode("utf-8"),
                          "application/json; charset=utf-8")

    def send_content(self, status, body, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        if self.server.verbose:
            super().log_message(format, *args)


def create_server(database, port=8000, *, demo=False, verbose=False):
    storage = Reservations(database)
    storage.initialize(demo)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.reservations = storage
    server.verbose = verbose
    return server


def main():
    parser = argparse.ArgumentParser(description="Inicia la recepción de Reserva Fácil.")
    parser.add_argument("--db", type=Path, default=Path("reservas.sqlite3"))
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--demo", action="store_true", help="Cargar una reserva ficticia en una base nueva.")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    with create_server(args.db, args.port, demo=args.demo, verbose=args.verbose) as server:
        print(f"Reserva Fácil disponible en http://127.0.0.1:{server.server_port}", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
