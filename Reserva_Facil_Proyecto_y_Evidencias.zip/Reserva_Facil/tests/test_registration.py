import sqlite3
import unittest
from concurrent.futures import ThreadPoolExecutor

from tests.support import call, running_demo


def booking(room, start, end, guest="Andrea Prueba"):
    return {"room_id": room, "guest": guest, "start": start, "end": end}


def saved_reservations(database):
    with sqlite3.connect(database) as db:
        return db.execute("SELECT room_id, guest, status FROM reservations ORDER BY id").fetchall()


class RegistrationTests(unittest.TestCase):
    def test_cp02_records_guest_and_room(self):
        with running_demo() as (url, database):
            status, data = call(url, "/api/reservations", booking(102, "2026-12-11", "2026-12-12"))
            persisted = saved_reservations(database)
        self.assertEqual(status, 201)
        self.assertEqual(data, {"id": 2, "status": "Activa"})
        self.assertEqual(persisted[-1], (102, "Andrea Prueba", "Activa"))

    def test_cp03_rejects_partial_overlap(self):
        with running_demo() as (url, database):
            status, data = call(url, "/api/reservations", booking(101, "2026-12-12", "2026-12-14"))
            persisted = saved_reservations(database)
        self.assertEqual(status, 409)
        self.assertIn("reservada", data["error"])
        self.assertEqual(len(persisted), 1)

    def test_cp04_rejects_duplicate_dates(self):
        with running_demo() as (url, database):
            status, _ = call(url, "/api/reservations", booking(101, "2026-12-10", "2026-12-13"))
            persisted = saved_reservations(database)
        self.assertEqual(status, 409)
        self.assertEqual(len(persisted), 1)

    def test_cp05_accepts_new_check_in_on_previous_check_out_date(self):
        with running_demo() as (url, database):
            status, _ = call(url, "/api/reservations", booking(101, "2026-12-13", "2026-12-14"))
            persisted = saved_reservations(database)
        self.assertEqual(status, 201)
        self.assertEqual(len(persisted), 2)

    def test_extra_only_one_simultaneous_booking_is_persisted(self):
        with running_demo() as (url, database):
            payload = booking(103, "2026-12-11", "2026-12-12")
            with ThreadPoolExecutor(max_workers=2) as pool:
                first = pool.submit(call, url, "/api/reservations", payload)
                second = pool.submit(call, url, "/api/reservations", payload)
                statuses = sorted((first.result()[0], second.result()[0]))
            persisted = saved_reservations(database)
        self.assertEqual(statuses, [201, 409])
        self.assertEqual(sum(room == 103 for room, _, _ in persisted), 1)
