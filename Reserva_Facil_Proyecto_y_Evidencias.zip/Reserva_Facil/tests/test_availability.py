import unittest

from tests.support import call, running_demo


class AvailabilityTests(unittest.TestCase):
    def test_cp01_availability_omits_room_with_overlapping_reservation(self):
        with running_demo() as (url, _):
            status, data = call(url, "/api/availability?start=2026-12-11&end=2026-12-12")
        self.assertEqual(status, 200)
        self.assertEqual([room["id"] for room in data["rooms"]], [102, 103])

    def test_cp06_rejects_check_out_equal_to_check_in(self):
        with running_demo() as (url, _):
            status, data = call(url, "/api/availability?start=2026-12-13&end=2026-12-13")
        self.assertEqual(status, 400)
        self.assertIn("posterior", data["error"])
