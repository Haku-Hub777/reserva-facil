import unittest

from tests.support import call, running_demo


class CancellationTests(unittest.TestCase):
    def test_cp08_cancel_retains_record_and_releases_room(self):
        with running_demo() as (url, _):
            status, cancellation = call(url, "/api/reservations/1/cancel", method="PATCH")
            again, retry = call(url, "/api/reservations/1/cancel", method="PATCH")
            _, listing = call(url, "/api/reservations")
            _, available = call(url, "/api/availability?start=2026-12-11&end=2026-12-12")
        self.assertEqual((status, again), (200, 200))
        self.assertEqual(cancellation, {"id": 1, "room_id": 101, "status": "Cancelada"})
        self.assertEqual(retry, cancellation)
        self.assertEqual(listing["reservations"][0]["status"], "Cancelada")
        self.assertEqual([room["id"] for room in available["rooms"]], [101, 102, 103])
