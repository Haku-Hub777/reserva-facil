import json
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from server import create_server


@contextmanager
def running_demo():
    with TemporaryDirectory() as directory:
        database = Path(directory) / "test.sqlite3"
        with create_server(database, port=0, demo=True) as server:
            thread = Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
            thread.start()
            try:
                yield f"http://127.0.0.1:{server.server_port}", database
            finally:
                server.shutdown()
                thread.join()


def call(base_url, path, payload=None, *, method=None):
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    headers = {"Content-Type": "application/json"} if body is not None else {}
    request = Request(base_url + path, data=body, headers=headers, method=method)
    try:
        response = urlopen(request, timeout=5)
    except HTTPError as error:
        response = error
    with response:
        return response.code, json.load(response)
