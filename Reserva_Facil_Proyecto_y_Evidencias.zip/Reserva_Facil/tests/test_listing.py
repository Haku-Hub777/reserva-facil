import unittest

from tests.support import call, running_demo


class ListingTests(unittest.TestCase):
    def test_cp07_lists_reservations_with_id_and_state(self):
        with running_demo() as (url, _):
            status, data = call(url, "/api/reservations")
        self.assertEqual(status, 200)
        self.assertEqual(data["reservations"], [{
            "id": 1, "room_id": 101, "guest": "Huésped de prueba",
            "start": "2026-12-10", "end": "2026-12-13", "status": "Activa",
        }])
