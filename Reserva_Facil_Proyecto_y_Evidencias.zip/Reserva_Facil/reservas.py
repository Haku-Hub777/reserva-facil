"""Persistence and rules for a local hotel reservation desk."""

import sqlite3
from contextlib import contextmanager
from datetime import date


class InvalidReservation(ValueError):
    pass


class RoomUnavailable(ValueError):
    pass


class NotFound(ValueError):
    pass


def validate_interval(start, end):
    try:
        check_in = date.fromisoformat(start)
        check_out = date.fromisoformat(end)
    except (TypeError, ValueError):
        raise InvalidReservation("Indica una fecha de entrada y una de salida válidas.") from None
    if start != check_in.isoformat() or end != check_out.isoformat() or check_out <= check_in:
        raise InvalidReservation("La fecha de salida debe ser posterior a la entrada.")


class Reservations:
    def __init__(self, database):
        self.database = database

    @contextmanager
    def connection(self):
        connection = sqlite3.connect(self.database, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def initialize(self, demo=False):
        with self.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS rooms (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    capacity INTEGER NOT NULL CHECK (capacity > 0)
                );
                CREATE TABLE IF NOT EXISTS reservations (
                    id INTEGER PRIMARY KEY,
                    room_id INTEGER NOT NULL REFERENCES rooms(id),
                    guest TEXT NOT NULL,
                    start TEXT NOT NULL,
                    end TEXT NOT NULL CHECK (start < end),
                    status TEXT NOT NULL DEFAULT 'Activa'
                        CHECK (status IN ('Activa', 'Cancelada'))
                );
                CREATE INDEX IF NOT EXISTS active_reservations
                    ON reservations (room_id, start, end) WHERE status = 'Activa';
            """)
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM rooms LIMIT 1").fetchone() is None:
                self.seed(db, demo)

    @staticmethod
    def seed(db, demo):
        db.executemany("INSERT INTO rooms (id, kind, capacity) VALUES (?, ?, ?)", [
            (101, "Individual", 1), (102, "Doble", 2), (103, "Familiar", 4),
        ])
        if demo:
            db.execute(
                "INSERT INTO reservations (room_id, guest, start, end) VALUES (?, ?, ?, ?)",
                (101, "Huésped de prueba", "2026-12-10", "2026-12-13"),
            )

    def available(self, start, end):
        validate_interval(start, end)
        with self.connection() as db:
            rows = db.execute("""
                SELECT id, kind, capacity FROM rooms
                WHERE NOT EXISTS (
                    SELECT 1 FROM reservations
                    WHERE room_id = rooms.id AND status = 'Activa'
                      AND start < ? AND end > ?
                )
                ORDER BY id
            """, (end, start))
            return [dict(row) for row in rows]


    def create(self, values):
        room_id = values.get("room_id")
        guest = values.get("guest")
        start = values.get("start")
        end = values.get("end")
        validate_interval(start, end)
        if type(room_id) is not int or room_id not in range(1, 10000):
            raise InvalidReservation("Selecciona una habitación válida.")
        if not isinstance(guest, str) or not 1 <= len(guest.strip()) <= 100:
            raise InvalidReservation("Escribe un nombre de huésped de hasta 100 caracteres.")

        with self.connection() as db:
            # Serialize the overlap check and the insert across concurrent requests.
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM rooms WHERE id = ?", (room_id,)).fetchone() is None:
                raise NotFound("La habitación no existe.")
            overlap = db.execute("""
                SELECT 1 FROM reservations
                WHERE room_id = ? AND status = 'Activa' AND start < ? AND end > ?
                LIMIT 1
            """, (room_id, end, start)).fetchone()
            if overlap:
                raise RoomUnavailable("La habitación ya está reservada en parte del intervalo.")
            inserted = db.execute("""
                INSERT INTO reservations (room_id, guest, start, end)
                VALUES (?, ?, ?, ?)
            """, (room_id, guest.strip(), start, end))
            return {"id": inserted.lastrowid, "status": "Activa"}


    def list_all(self):
        with self.connection() as db:
            rows = db.execute("""
                SELECT id, room_id, guest, start, end, status
                FROM reservations
                ORDER BY start, id
            """)
            return [dict(row) for row in rows]


    def cancel(self, reservation_id):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            room = db.execute(
                "SELECT room_id FROM reservations WHERE id = ?", (reservation_id,)
            ).fetchone()
            if room is None:
                raise NotFound("La reserva no existe.")
            db.execute("""
                UPDATE reservations SET status = 'Cancelada'
                WHERE id = ? AND status = 'Activa'
            """, (reservation_id,))
            return {"id": reservation_id, "room_id": room["room_id"], "status": "Cancelada"}
