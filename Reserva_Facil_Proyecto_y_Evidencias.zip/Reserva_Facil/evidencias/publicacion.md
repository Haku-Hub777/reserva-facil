# Publicación y trazabilidad

## Repositorio

El historial Git conserva los cambios y las marcas reales de la sesión técnica. Si se dispone de un repositorio GitHub vacío, se puede publicar el historial original desde el archivo bundle. No inicializar el repositorio remoto con un README si se quiere publicar el historial original sin otro commit de raíz.

Desde la carpeta que contiene el bundle, sustituir la URL por la del repositorio de Reserva Fácil:

```powershell
git clone reserva-facil.bundle reserva-facil-git
cd reserva-facil-git
git remote set-url origin https://github.com/USUARIO/reserva-facil.git
git push -u origin main
```

## Tablero

Configurar un proyecto separado de Reserva Fácil. El archivo `backlog_para_jira.csv` contiene las cuatro historias, sus criterios, puntos en la descripción y la referencia a los commits. Está preparado con columnas genéricas de importación. En Jira, asignar el tipo de incidencia y los campos según las opciones del proyecto. Los movimientos ya registrados están en `movimientos.csv`. La fecha de importación indicará cuándo se creó la tarjeta en Jira, y la bitácora registrará cuándo se trabajó originalmente.

## Verificación final

Abrir repositorio, tablero, formulario y mapa de historias como la docente. Si la entrega exige lectura sin iniciar sesión, probar cada dirección en una ventana de incógnito antes de radicar. Anotar fecha, enlace y resultado de cada prueba de acceso.
