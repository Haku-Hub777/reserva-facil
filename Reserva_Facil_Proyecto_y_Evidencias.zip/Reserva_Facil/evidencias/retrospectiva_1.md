# Retrospectiva del sprint 1

Acta técnica del ciclo de recuperación. Elaborada con asistencia de IA. Revisión y firma académica del responsable pendientes.

## Resultado

Se terminó la consulta y el alta, HU-01 y HU-02. Pasaron los seis casos del alcance y una prueba concurrente adicional. El navegador Chromium no pudo iniciar en el entorno de ejecución. Se comprobó la entrega de HTML, CSS y JavaScript por HTTP y la sintaxis de JavaScript. La validación visual quedó por completar.

## Observaciones y acciones

| ID | Observación sustentada | Acción para el sprint 2 | Constancia que debe quedar |
| --- | --- | --- | --- |
| M1 | HU-02 entró a En progreso antes del cierre de HU-01. El máximo fue de dos tarjetas simultáneas. | Abrir HU-04 solo tras cerrar HU-03. | El historial del segundo sprint debe mostrar un WIP máximo de una tarjeta. |
| M2 | Las pruebas individuales de HU-01 se ejecutaron, y la evidencia persistente del ciclo se agrupó en el reporte general. La trazabilidad por cierre dependía del texto de movimientos. | Guardar la salida de la prueba de cada HU del segundo sprint antes de cerrarla. | Para HU-03 y HU-04, adjuntar reporte individual en el mismo commit de la historia. |

Responsable técnico de aplicar las mejoras: asistente de IA. Responsable académico de revisar el registro: Juan José Montoya Garzón.
