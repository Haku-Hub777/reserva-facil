# Acta de constitución de Reserva Fácil

Fecha de registro: 17 de noviembre de 2026. Modalidad de recuperación individual de Gerencia de Software. Responsable académico: Juan José Montoya Garzón. La versión inicial del alcance está en el commit `c94d349`.

## Objetivo

Construir un prototipo de recepción que consulte habitaciones disponibles, cree reservas válidas, rechace solapamientos en una misma habitación y restituya la disponibilidad tras la cancelación. El flujo incluye identificar la reserva por código o por huésped.

## Criterios de cierre

Completar las cuatro historias de la primera versión, aprobar sus ocho casos funcionales y entregar el código, las instrucciones de ejecución y las evidencias. La validación del cliente se evalúa por separado con el instrumento de satisfacción.

## Capacidad y restricciones

Se estimaron 6 horas por ciclo como referencia de planeación. El registro disponible mide tiempo transcurrido en una sesión técnica asistida de recuperación. La aplicación se limita al uso local y utiliza datos ficticios de prueba. El perfil objetivo es recepción hotelera. La revisión y la firma del estudiante quedan pendientes.

## Control

[Registro de cambios](cambios.csv). CC-01 ajustó los estándares de trabajo y de evidencia al pasar al segundo ciclo.
