# Retrospectiva del sprint 2

Acta técnica del ciclo de recuperación. Elaborada con asistencia de IA. Revisión y firma académica del responsable pendientes.

| Acción | Resultado comprobado | Fuente |
| --- | --- | --- |
| M1 | El máximo fue de una tarjeta simultánea. HU-04 entró en progreso después del cierre de HU-03, según el orden del registro. | movimientos.csv y metricas.json |
| M2 | Las dos historias tuvieron prueba específica archivada al cierre. | HU-03_prueba.txt en el commit 13308e2 y HU-04_prueba.txt en el commit 5e98898 |

Se completaron HU-03 y HU-04. La regresión cerró con ocho casos del alcance y una prueba adicional de concurrencia aprobados.

Quedó pendiente validar la experiencia con un perfil de recepción, registrar sus respuestas y comprobar la interfaz con un navegador disponible. Para una siguiente entrega académica, acordar la sesión con el evaluador en la planeación y probar las herramientas de verificación visual antes de iniciar el primer ciclo.
