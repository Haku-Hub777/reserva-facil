# Evidencias de Reserva Fácil

Las marcas de tiempo corresponden a una sesión de recuperación con asistencia de IA. Los dos ciclos se registraron en una bitácora local. Las métricas y gráficas se calculan desde ese registro.

| Evidencia | Ubicación |
| --- | --- |
| Repositorio y convenciones | Historial de Git y [ESTANDARES.md](../ESTANDARES.md) |
| Tablero de origen y burndown | [backlog.csv](backlog.csv), [movimientos.csv](movimientos.csv), [metricas.json](metricas.json), [burndown_sprint1.png](burndown_sprint1.png), [burndown_sprint2.png](burndown_sprint2.png) |
| Retrospectivas | [Sprint 1](retrospectiva_1.md) y [Sprint 2](retrospectiva_2.md) |
| Instrumento de satisfacción | [Formulario](formulario_satisfaccion.md) y [registro de respuestas](respuestas_satisfaccion.csv). Aplicación pendiente |
| Análisis estático | [Versión HU-01 reproducida](analisis_hu01_reproducido.txt), [corte sprint 1](analisis_sprint1.txt) y [corte sprint 2](analisis_sprint2.txt) |
| Pruebas | [Matriz](casos_prueba.csv), [corte sprint 1](pruebas_sprint1.txt), [corte sprint 2](pruebas_sprint2.txt) y pruebas individuales en los commits de HU-03 y HU-04 |
| Alcance y registro de cambios | [Mapa de historias](alcance.md), [acta de recuperación](acta_recuperacion.md), [cambios](cambios.csv) |

Los resultados funcionales de la matriz corresponden a pruebas HTTP y persistencia en SQLite. Las verificaciones adicionales de HTML, CSS y JavaScript se registran en `interfaz_sprint1.txt` e `interfaz_sprint2.txt`. El caso de uso con una persona externa y la comprobación visual en navegador permanecen pendientes.
