# Reserva Fácil

Prototipo web de recepción para un hotel pequeño. Permite consultar disponibilidad por fechas, registrar reservas, encontrarlas por nombre o identificador y cancelar reservas activas. SQLite conserva los datos entre ejecuciones.

## Inicio en Windows

Desde PowerShell, ubicado en la carpeta del proyecto con Python 3.10 o superior:

```powershell
py -3 server.py --demo
```

Abre [Reserva Fácil](http://127.0.0.1:8000) en el navegador. En Linux o macOS, usa `python3 server.py --demo`. El servidor está limitado a la máquina local. El archivo SQLite se crea al lado del proyecto desde donde se ejecuta el comando. Usa `--db ruta.sqlite3` para elegir otro archivo y `--port 8001` si el puerto 8000 ya está ocupado.

## Demostración

1. Con una base nueva, `--demo` carga las habitaciones 101, 102 y 103. La 101 tiene una reserva ficticia del 10 al 13 de diciembre de 2026.
2. Consulta del 11 al 12 de diciembre. Elige la 102, guarda una reserva para «Andrea Prueba» y verifica que la 102 salga de disponibilidad.
3. Filtra por «Andrea», cancela esa reserva y verifica que su estado cambie a «Cancelada» y que la 102 vuelva a aparecer.

Para repetir la demo desde cero, usa otro archivo nuevo. Por ejemplo, `py -3 server.py --demo --db practica.sqlite3`.

## Pruebas

```powershell
py -3 -m unittest discover -v
py -3 herramientas/analisis.py
py -3 herramientas/rendimiento.py
py -3 herramientas/verificar_interfaz.py
```

Las pruebas crean bases temporales. El reporte de rendimiento usa 30 solicitudes HTTP a la aplicación local. El analizador estático cuenta decisiones en las funciones Python del producto. Con Node.js disponible, `node --check web/app.js` comprueba la sintaxis de JavaScript.

## Entrega académica

- [ESTANDARES.md](ESTANDARES.md) conserva los estándares y las mejoras adoptadas tras el primer sprint.
- [Evidencias](evidencias/README.md) reúne el backlog, el mapa de historias, las pruebas, las retrospectivas y los registros de los ciclos.
