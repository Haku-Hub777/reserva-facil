"use strict";

const availability = document.querySelector("#availability");
const availabilityMessage = document.querySelector("#availability-message");
const rooms = document.querySelector("#rooms");
const reservation = document.querySelector("#new-reservation");
const saveReservation = document.querySelector("#save-reservation");
const selectedRoom = document.querySelector("#selected-room");
const reservationMessage = document.querySelector("#reservation-message");
const filter = document.querySelector("#reservation-filter");
const listMessage = document.querySelector("#list-message");
const tableRows = document.querySelector("#reservation-rows");
const cancellationDialog = document.querySelector("#cancellation-dialog");
const cancellationForm = document.querySelector("#cancellation-form");
const cancellationDetail = document.querySelector("#cancellation-detail");
const cancellationMessage = document.querySelector("#cancellation-message");
const keepReservation = document.querySelector("#keep-reservation");
const confirmCancellation = document.querySelector("#confirm-cancellation");
const dateFormat = new Intl.DateTimeFormat("es-CO", { dateStyle: "short" });
let savedReservations = [];
let listRevision = 0;
let searchRevision = 0;
let selection = null;
let saving = false;
let pendingCancellation = null;

function element(tag, text, className) {
  const node = document.createElement(tag);
  node.textContent = text;
  if (className) node.className = className;
  return node;
}

function message(target, text, isError = false) {
  target.textContent = text;
  target.classList.toggle("error", isError);
}

async function request(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error);
  return data;
}

function renderRoom(room, start, end) {
  const item = element("div", "", "room");
  const details = element("div", "");
  details.append(element("p", `Habitación ${room.id}`, "room-title"));
  const guests = room.capacity === 1 ? "persona" : "personas";
  details.append(element("p", `${room.kind} · ${room.capacity} ${guests}`, "room-detail"));
  const choose = element("button", "Elegir");
  choose.type = "button";
  choose.setAttribute("aria-label", `Elegir habitación ${room.id}`);
  choose.addEventListener("click", () => {
    selection = { room_id: room.id, start, end };
    selectedRoom.textContent = `Habitación ${room.id} · ${start} a ${end}`;
    saveReservation.disabled = saving;
    message(reservationMessage, "");
    reservation.elements.guest.focus();
  });
  item.append(details, choose);
  return item;
}

function clearSelection() {
  selection = null;
  saveReservation.disabled = true;
  selectedRoom.textContent = "Elige una habitación de la lista de disponibilidad.";
}

function clearAvailability() {
  searchRevision += 1;
  rooms.replaceChildren();
  clearSelection();
  message(availabilityMessage, "");
}

async function searchAvailability() {
  const revision = ++searchRevision;
  rooms.replaceChildren();
  clearSelection();
  message(availabilityMessage, "Consultando disponibilidad…");
  try {
    const query = new URLSearchParams(new FormData(availability));
    const result = await request(`/api/availability?${query}`);
    if (revision !== searchRevision) return;
    rooms.replaceChildren(...result.rooms.map(
      (room) => renderRoom(room, query.get("start"), query.get("end"))
    ));
    const count = result.rooms.length;
    const status = count === 1 ? "1 habitación disponible." : `${count} habitaciones disponibles.`;
    message(availabilityMessage, status);
  } catch (error) {
    if (revision === searchRevision) message(availabilityMessage, error.message, true);
  }
}

availability.addEventListener("input", clearAvailability);
availability.addEventListener("submit", (event) => {
  event.preventDefault();
  searchAvailability();
});


reservation.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!selection || saving) return;
  saving = true;
  saveReservation.disabled = true;
  message(reservationMessage, "Guardando reserva…");
  const guest = reservation.elements.guest.value;
  try {
    const result = await request("/api/reservations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...selection, guest }),
    });
    reservation.reset();
    message(reservationMessage, `Reserva #${result.id} guardada.`);
    await Promise.all([searchAvailability(), loadReservations()]);
  } catch (error) {
    message(reservationMessage, error.message, true);
    await searchAvailability();
  } finally {
    saving = false;
    saveReservation.disabled = !selection;
  }
});


function formatDate(value) {
  return dateFormat.format(new Date(`${value}T00:00:00`));
}

function renderReservation(item) {
  const row = element("tr", "");
  row.append(element("td", `#${item.id}`), element("td", item.guest),
    element("td", item.room_id), element("td", formatDate(item.start)),
    element("td", formatDate(item.end)));
  const status = element("td", "");
  const cancelled = item.status === "Cancelada";
  status.append(element("span", item.status, cancelled ? "state cancelled" : "state"));
  const action = element("td", "");
  if (!cancelled) {
    const cancel = element("button", "Cancelar", "danger");
    cancel.type = "button";
    cancel.setAttribute("aria-label", `Cancelar reserva ${item.id}`);
    cancel.addEventListener("click", () => openCancellation(item));
    action.append(cancel);
  }
  row.append(status, action);
  return row;
}

function renderReservations() {
  const query = filter.value.trim().toLocaleLowerCase("es-CO");
  const id = /^#?\d+$/.test(query) ? query.replace(/^#/, "") : null;
  const shown = savedReservations.filter((item) =>
    id !== null ? String(item.id) === id : item.guest.toLocaleLowerCase("es-CO").includes(query)
  );
  tableRows.replaceChildren(...shown.map(renderReservation));
  message(listMessage, shown.length ? "" : "No hay reservas para mostrar.");
}

async function loadReservations() {
  const revision = ++listRevision;
  try {
    const result = await request("/api/reservations");
    if (revision !== listRevision) return;
    savedReservations = result.reservations;
    renderReservations();
  } catch (error) {
    if (revision === listRevision) message(listMessage, error.message, true);
  }
}

filter.addEventListener("input", renderReservations);
loadReservations();


function openCancellation(item) {
  pendingCancellation = item.id;
  cancellationDetail.textContent = `Se liberará la habitación ${item.room_id} para las fechas de la reserva #${item.id}.`;
  message(cancellationMessage, "");
  cancellationDialog.showModal();
}

keepReservation.addEventListener("click", () => cancellationDialog.close());
cancellationDialog.addEventListener("cancel", (event) => {
  if (confirmCancellation.disabled) event.preventDefault();
});
cancellationForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (pendingCancellation === null || confirmCancellation.disabled) return;
  confirmCancellation.disabled = true;
  keepReservation.disabled = true;
  try {
    await request(`/api/reservations/${pendingCancellation}/cancel`, { method: "PATCH" });
    cancellationDialog.close();
    await Promise.all([loadReservations(), searchAvailability()]);
  } catch (error) {
    message(cancellationMessage, error.message, true);
  } finally {
    confirmCancellation.disabled = false;
    keepReservation.disabled = false;
  }
});
