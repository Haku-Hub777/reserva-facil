"""Measure 30 sequential HTTP requests against the local demo."""

import json
import math
import platform
import sqlite3
from pathlib import Path
from sys import path
from time import perf_counter_ns

path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests.support import call, running_demo


def main():
    endpoint = "/api/availability?start=2026-12-11&end=2026-12-12"
    times = []
    with running_demo() as (url, _):
        call(url, endpoint)  # Warm-up, excluded from the sample.
        for _ in range(30):
            start = perf_counter_ns()
            status, data = call(url, endpoint)
            times.append((perf_counter_ns() - start) / 1_000_000)
            if status != 200 or [room["id"] for room in data["rooms"]] != [102, 103]:
                raise RuntimeError("El endpoint no devolvió la disponibilidad prevista.")
    p95 = sorted(times)[math.ceil(len(times) * 0.95) - 1]
    print(json.dumps({
        "metodo": "HTTP local, 30 consultas secuenciales, una consulta de calentamiento",
        "condiciones": "Inicia con tres habitaciones y una reserva ficticia",
        "python": platform.python_version(),
        "sqlite": sqlite3.sqlite_version,
        "entorno": f"{platform.system()} {platform.machine()}",
        "muestras_ms": [round(value, 3) for value in times],
        "p95_ms": round(p95, 3),
    }, ensure_ascii=False, indent=2))
    if p95 > 1000:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
