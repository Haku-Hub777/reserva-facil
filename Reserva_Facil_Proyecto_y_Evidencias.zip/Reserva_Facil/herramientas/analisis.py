"""Report cyclomatic complexity for Python product functions."""

import ast
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FUNCTIONS = (ast.FunctionDef, ast.AsyncFunctionDef)
DECISIONS = (ast.If, ast.IfExp, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler)


def complexity(function):
    total = 1
    for node in ast.walk(function):
        if isinstance(node, DECISIONS):
            total += 1
        elif isinstance(node, ast.BoolOp):
            total += len(node.values) - 1
        elif isinstance(node, ast.comprehension):
            total += 1 + len(node.ifs)
        elif isinstance(node, ast.Match):
            total += max(0, len(node.cases) - 1)
    return total


def main():
    print(f"Medición local: {datetime.now().astimezone().isoformat(timespec='seconds')}")
    print("Método: AST de Python. Base 1, más decisiones, except y ramas booleanas.")
    print("Alcance: reservas.py y server.py. Umbral máximo: 10.")
    peak = 0
    for filename in ("reservas.py", "server.py"):
        tree = ast.parse((ROOT / filename).read_text(encoding="utf-8"))
        for node in sorted(ast.walk(tree), key=lambda item: getattr(item, "lineno", 0)):
            if isinstance(node, FUNCTIONS):
                score = complexity(node)
                peak = max(peak, score)
                print(f"{filename}:{node.lineno} {node.name:<22} {score}")
    print(f"Máximo: {peak}.")
    if peak > 10:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
