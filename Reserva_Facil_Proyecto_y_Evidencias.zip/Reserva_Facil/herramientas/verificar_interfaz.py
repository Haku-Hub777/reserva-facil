"""Verify that the local HTTP server delivers its interface and assets."""

import re
import sys
from pathlib import Path
from urllib.request import urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests.support import running_demo


def read(base_url, location, expected_type):
    with urlopen(base_url + location, timeout=5) as response:
        assert response.status == 200
        assert response.headers.get_content_type() == expected_type
        return response.read().decode("utf-8")


with running_demo() as (url, _):
    page = read(url, "/", "text/html")
    script = read(url, "/app.js", "text/javascript")
    read(url, "/style.css", "text/css")
    ids = set(re.findall(r'\bid="([^"]+)"', page))
    selectors = set(re.findall(r'querySelector\("#([\w-]+)"\)', script))
    assert selectors <= ids, sorted(selectors - ids)
    print("HTML, CSS y JavaScript servidos por HTTP con tipos correctos.")
    print(f"{len(selectors)} selectores directos de JavaScript coinciden con IDs del HTML.")
