"""Append one actual board event with a Bogotá timestamp."""

import csv
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

path = Path(__file__).resolve().parents[1] / "evidencias" / "movimientos.csv"
fields = ("fecha_bogota", "sprint", "tarjeta", "evento", "detalle")
sprint, card, event, detail = sys.argv[1:]
new_log = not path.exists()
with path.open("a", encoding="utf-8", newline="") as output:
    writer = csv.writer(output, lineterminator="\n")
    if new_log:
        writer.writerow(fields)
    writer.writerow((datetime.now(ZoneInfo("America/Bogota")).isoformat(timespec="seconds"),
                     sprint, card, event, detail))
